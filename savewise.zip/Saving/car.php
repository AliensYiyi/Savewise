<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Deposit Form</title>
    <style>
        body {
            font-family: sans-serif;
            display: flex;
            flex-direction: column;
            height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
        }
        
        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;;
            margin-top: 50px;
        }

        .form-header {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 20px;
        }

        .form-header img {
            width: 50px;
            height: 50px;
        }

        .form-header h2 {
            margin: 10px 0 0;
            font-size: 20px;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            margin-bottom: 5px;
            color: #333;
        }

        .form-group input {
            width: calc(100% - 10px);
            padding: 8px 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 14px;
        }

        .form-inline {
            display: flex;
            justify-content: space-between;
        }

        .form-inline input {
            width: 48%;
        }

        button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #0056b3;
        }

    </style>
</head>
<body>
    
    <?php include('navigation.php'); ?>
    
    <div class="box">
        <div class="form-container">
        <div class="form-header">
            <img src="photo/car.png" alt="Car Key Icon">
            <h2>Car Deposit</h2>
        </div>
        <form action="car_result.php" method="post">
            <div class="form-group">
                <label for="price">Price</label>
                <input type="number" id="price" name="price" min="0" required>
            </div>
            <div class="form-group">
                <label for="deposit">Deposit (%)</label>
                <input type="number" id="deposit" name="deposit" min="0" required>
            </div>
            <div class="form-group">
                <label for="buy-before-month">Buy Before</label>
                <div class="form-inline">
                    <input type="number" id="buy-before-year" name="buy_before_year" placeholder="Year" min="0" required>
                    <input type="number" id="buy-before-month" name="buy_before_month" placeholder="Month" min="0" required>
                </div>
            </div>
            <button type="submit">Next</button>
        </form>
    </div>
    </div>
    
</body>
</html>
