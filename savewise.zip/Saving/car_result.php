<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $price = $_POST['price'];
    $deposit = $_POST['deposit'];
    $buy_before_month = $_POST['buy_before_month'];
    $buy_before_year = $_POST['buy_before_year'];

    // Calculate the number of months left until the buying date
    $total_Month = ($buy_before_year) * 12 + ($buy_before_month);

    // Calculate the monthly target
    $deposit_amount = $price * ( $deposit / 100);
    $price_amount = $price - $deposit_amount;
    $monthly_target = $deposit_amount / $total_Month;

    // Include your database connection file
    include "../conn.php";

    // Get user ID from session
    $userId = $_SESSION['user_id'];

    $stmt = $conn->prepare("SELECT total_id FROM total WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($totalId);
    $stmt->fetch();
    $stmt->close();

    if (!$totalId) {
        // If the user does not have a total_id, redirect to the income entry page or show a message
        echo "<script>alert('Please Enter Income First.'); window.location.href='mainpage.php';</script>";
        exit();
        exit();
    }

    // Insert the calculated saving goal into the Saving table
    $stmt = $conn->prepare("INSERT INTO saving (Total_id, Saving_name, Saving_month, Saving_amount, saving_total) VALUES (?, ?, ?, ?, ?)");
    $saving_name = 'Car Deposit'; // You can change this or make it dynamic based on your needs
    $saving_set = $total_Month; // The total amount needed to save
    $saving_current = $monthly_target; // Starting at 0 for new savings goal
    $saving_total = $deposit_amount;

    $stmt->bind_param("isddd", $userId, $saving_name, $saving_set, $saving_current, $saving_total);
    $stmt->execute();

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saving Goal</title>
    <style>
        body {
            font-family: sans-serif;
            height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
        }
        
        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .goal-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
            margin-top: 40px;;
        }

        .goal-header {
            margin-bottom: 20px;
        }

        .goal-content {
            border: 1px solid #ccc;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        .goal-content img {
            width: 30px;
            height: 30px;
            vertical-align: middle;
            margin-right: 10px;
        }

        .goal-content p {
            margin: 0;
            font-size: 16px;
        }

        button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 14px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<?php include('../navigation.php'); ?>
    <div class="box">
        <div class="goal-container">
        <div class="goal-header">
            <p>To achieve your saving goal you need to save the related amount every month</p>
        </div>
        <div class="goal-content">
            <p>Monthly Target</p>
            <p><strong>RM <?php echo number_format($monthly_target, 2); ?> / Month </p>
            <p>For <?php echo $total_Month; ?> months</strong></p>
        </div> 
        <div class="goal-content">
            <img src="photo/car.png" alt="Car Key Icon">
            <p>Car Deposit</p>
            <p><strong>RM <?php echo number_format($deposit_amount, 2); ?> 
        </div>
        <form method="post" action="mainpage.php">
            <button type="submit">Back to Saving</button>
        </form>
    </div>
    </div>
    
</body>
</html>
