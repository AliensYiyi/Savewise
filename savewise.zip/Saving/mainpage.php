<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Build Your Own Saving Goal</title>
    <style>
        body {
            font-family: sans-serif;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f4f4f4;
            margin: 0;
        }

        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 600px;
            text-align: center;
            margin-top:40px;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        .options {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .option {
            display: flex;
            align-items: center;
            padding: 15px;
            border-radius: 5px;
            background-color: #f8f8f8;
            border: 1px solid #ddd;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .option:hover {
            background-color: #e9e9e9;
        }

        .icon {
            width: 30px;
            height: 30px;
            margin-right: 15px;
        }

        .label {
            font-size: 16px;
            color: #333;
        }

        .radio {
            margin-left: auto;
            margin-right: 10px;
        }

        button {
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
            width: 100%;
        }

        button:hover {
            background-color: #0062cc;
        }

        @media (min-width: 768px) {
            .container {
                padding: 30px;
                margin-top: 20px;
            }

            .option {
                padding: 20px;
            }

            button {
                width: auto;
                margin-top: 20px;
            }
        }
    </style>
</head>
<body>

    <?php include('navigation.php'); ?>
    <div class="box">
        <div class="container">
            <h2>Build Your Own Saving Goal</h2>

            <div class="options">
                <div class="option">
                    <img src="https://img.icons8.com/ios-filled/50/000000/alarm--v1.png" alt="Emergency" class="icon">
                    <span class="label">Emergency</span>
                    <input type="radio" name="goal" value="emergency.php" class="radio">
                </div>

                <div class="option">
                    <img src="photo/home.png" alt="House Deposit" class="icon">
                    <span class="label">House Deposit</span>
                    <input type="radio" name="goal" value="home.php" class="radio">
                </div>

                <div class="option">
                    <img src="photo/car.png" alt="Car Deposit" class="icon">
                    <span class="label">Car Deposit</span>
                    <input type="radio" name="goal" value="car.php" class="radio">
                </div>

                <div class="option">
                    <img src="https://img.icons8.com/ios-filled/50/000000/plus-math.png" alt="Custom" class="icon">
                    <span class="label">Custom</span>
                    <input type="radio" name="goal" value="custom.php" class="radio">
                </div>
            </div>

            <button onclick="redirectToGoal()">Next</button>
        </div>
    </div>

    <script>
        function redirectToGoal() {
            // Get all radio buttons
            var radios = document.getElementsByName('goal');
            var selectedValue;
            
            // Check which radio button is selected
            for (var i = 0; i < radios.length; i++) {
                if (radios[i].checked) {
                    selectedValue = radios[i].value;
                    break;
                }
            }

            // Redirect to the selected value (URL)
            if (selectedValue) {
                window.location.href = selectedValue;
            } else {
                alert("Please select a goal.");
            }
        }
    </script>

</body>
</html>
