<?php if (session_status() == PHP_SESSION_NONE) {
    session_start();
} ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Header</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .site-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 2cm; /* Height of the header */
            background-color: #fff;
            border-bottom: 1px solid #ccc;
            padding: 0 1em;
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            height: 24px; /* Adjust the height of the logo as needed */
            margin-right: 8px;
        }

        .site-nav {
            display: flex;
            align-items: center;
        }

        .site-nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #000;
            margin-right: 50px;
        }

        .site-nav a:hover {
            color: blue;
            background-color: lightblue; /* Adjust background color as needed */
        }

        .user-info {
            margin-left: auto;
            padding: 0 1em;
        }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="logo">
            <img src="logo.png" alt="Logo">
        </div>
        <nav class="site-nav">
            <a href="../mainpage.php" style="margin-left: 160px;">Main Menu</a>
            <a href="../income.php">Income</a>
            <a href="../budget.php">Budget</a>
            <a href="../transaction.php">Transaction</a>
            <a href="mainpage.php">Saving</a>
            <a href="../investment.php">Investment</a>
            <a href="../loanCalculator.php">Loan Calculator</a>
            <a href="../customerService.php">Customer Service</a>
        </nav>
        <?php if (isset($_SESSION['user_id'])): ?>
            <div class="user-info">
                User ID: <?php echo $_SESSION['user_id']; ?>
            </div>
        <?php endif; ?>
    </header>
</body>
</html>
