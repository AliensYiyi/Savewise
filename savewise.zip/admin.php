<?php
session_start();
include "conn.php";

// Handle message sending
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userId = intval($_POST['user_id']);
    $message = trim($_POST['message']);

    $stmt = $conn->prepare("INSERT INTO chat (user_id, message, sender_role) VALUES (?, ?, 'Admin')");
    $stmt->bind_param("is", $userId, $message);
    $stmt->execute();
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Chat</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            height: 100vh;
        }

        .chat-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            width: 600px;
            max-width: 90%;
            display: flex;
            flex-direction: column;
            height: 80vh;
            margin: auto;
            margin-top: 20px;
        }

        .chat-header {
            margin-bottom: 20px;
            text-align: center;
        }

        .chat-box {
            border: 1px solid #ddd;
            border-radius: 10px;
            height: calc(100% - 100px); /* Fixed height for chat-box */
            overflow-y: auto;
            padding: 20px;
            background-color: #f9f9f9;
            flex: 1;
        }

        .message {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            max-width: 80%;
        }

        .message.user {
            background-color: #e0ffe0;
            align-self: flex-start;
        }

        .message.admin {
            background-color: #e0e0ff;
            align-self: flex-end;
            margin-left: 100px;
        }

        .message p {
            margin: 5px 0;
        }

        .message small {
            align-self: flex-end;
            color: #666;
        }

        .form-group {
            display: flex;
            margin-top: 20px;
        }

        .form-group select,
        .form-group input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px 0 0 5px;
            font-size: 16px;
        }

        .form-group select {
            flex: 1;
            margin-right: 10px;
        }

        .form-group input {
            flex: 2;
        }

        .form-group button {
            padding: 10px 20px;
            border: none;
            border-radius: 0 5px 5px 0;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        function scrollToBottom() {
            var chatBox = document.querySelector('.chat-box');
            chatBox.scrollTop = chatBox.scrollHeight;
        }

        function fetchMessages(userId) {
            fetch('admin_fetch_messages.php?user_id=' + userId)
                .then(response => response.json())
                .then(data => {
                    const chatBox = document.querySelector('.chat-box');
                    chatBox.innerHTML = '';
                    data.forEach(message => {
                        const messageDiv = document.createElement('div');
                        messageDiv.classList.add('message', message.sender_role.toLowerCase());
                        messageDiv.innerHTML = `<p><strong>${message.sender_role}:</strong></p>
                                                <p>${message.message}</p>
                                                <small>${message.created_at}</small>`;
                        chatBox.appendChild(messageDiv);
                    });
                    scrollToBottom();
                });
        }

        document.addEventListener('DOMContentLoaded', function () {
            const userIdSelect = document.querySelector('select[name="user_id"]');
            const currentUserId = document.querySelector('input[name="current_user_id"]').value;

            userIdSelect.value = currentUserId;
            fetchMessages(currentUserId);

            userIdSelect.addEventListener('change', function() {
                document.querySelector('input[name="current_user_id"]').value = this.value;
                fetchMessages(this.value);
            });

            setInterval(function() {
                fetchMessages(userIdSelect.value);
            }, 5000); // Fetch messages every 5 seconds
        });

        // Emoji validation function
        function containsEmoji(str) {
            const regex = /[\uD83C-\uDBFF\uDC00-\uDFFF]+/g;
            return regex.test(str);
        }

        // Form submission handler with validation
        function handleSubmit(event) {
            const messageInput = document.querySelector('input[name="message"]');
            if (containsEmoji(messageInput.value)) {
                alert('Emojis are not allowed in the message.');
                event.preventDefault();
            }
        }

        document.addEventListener('DOMContentLoaded', function () {
            const form = document.querySelector('form');
            form.addEventListener('submit', handleSubmit);
        });
    </script>
</head>
<body>
    <?php include('admin_navigation.php'); ?>
    <div class="chat-container">
        <h2 class="chat-header">Customer Service Chat</h2>
        <div class="chat-box"></div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <input type="hidden" name="current_user_id" value="<?php echo isset($_POST['user_id']) ? intval($_POST['user_id']) : ''; ?>">
                <select name="user_id" required>
                    <?php
                    $result = $conn->query("SELECT DISTINCT chat.user_id, user.user_name FROM chat JOIN user ON chat.user_id = user.user_id");
                    while ($row = $result->fetch_assoc()) {
                        $selected = (isset($_POST['user_id']) && intval($_POST['user_id']) == $row['user_id']) ? 'selected' : '';
                        echo "<option value='{$row['user_id']}' $selected>{$row['user_name']}</option>";
                    }
                    $conn->close();
                    ?>
                </select>
                <input type="text" name="message" placeholder="Type your message here..." required>
                <button type="submit">Send</button>
            </div>
        </form>
    </div>
</body>
</html>
