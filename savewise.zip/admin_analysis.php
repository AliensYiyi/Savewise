<?php
session_start();
include "conn.php";

// Ensure only admin can access this page
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch number of customers
$stmt = $conn->prepare("SELECT COUNT(*) as customer_count FROM user");
$stmt->execute();
$stmt->bind_result($customerCount);
$stmt->fetch();
$stmt->close();

// Fetch average customer income
$stmt = $conn->prepare("SELECT AVG(total_income) as avg_income FROM total");
$stmt->execute();
$stmt->bind_result($avgIncome);
$stmt->fetch();
$stmt->close();

// Fetch total investment
$stmt = $conn->prepare("SELECT SUM(investment_amount) as total_investment FROM investments");
$stmt->execute();
$stmt->bind_result($totalInvestment);
$stmt->fetch();
$stmt->close();

// Fetch top 5 customers by investment
$stmt = $conn->prepare("SELECT user.user_name, investments.investment_amount FROM user 
                        JOIN total ON user.user_id = total.user_id 
                        JOIN investments ON total.total_id = investments.total_id 
                        ORDER BY investments.investment_amount DESC LIMIT 5");
$stmt->execute();
$result = $stmt->get_result();
$topCustomers = [];
while ($row = $result->fetch_assoc()) {
    $topCustomers[] = $row;
}
$stmt->close();

// Fetch average investment per customer
$stmt = $conn->prepare("SELECT AVG(investment_amount) as avg_investment FROM investments");
$stmt->execute();
$stmt->bind_result($avgInvestment);
$stmt->fetch();
$stmt->close();

// Fetch number of transactions
$stmt = $conn->prepare("SELECT COUNT(*) as transaction_count FROM investmenthistory");
$stmt->execute();
$stmt->bind_result($transactionCount);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Analysis</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 800px;
            margin: 40px auto;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <?php include('admin_navigation.php'); ?>

    <div class="container">
        <h2>Admin Analysis</h2>
        <table>
            <tr>
                <th>Number of Customers</th>
                <td><?php echo $customerCount; ?></td>
            </tr>
            <tr>
                <th>Average Customer Income</th>
                <td>RM <?php echo number_format($avgIncome, 2); ?></td>
            </tr>
            <tr>
                <th>Total Investment</th>
                <td>RM <?php echo number_format($totalInvestment, 2); ?></td>
            </tr>
            <tr>
                <th>Average Investment per Customer</th>
                <td>RM <?php echo number_format($avgInvestment, 2); ?></td>
            </tr>
            <tr>
                <th>Number of Transactions</th>
                <td><?php echo $transactionCount; ?></td>
            </tr>
        </table>

        <h3>Top 5 Customers by Investment</h3>
        <table>
            <thead>
                <tr>
                    <th>Customer Name</th>
                    <th>Total Investment</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($topCustomers as $customer): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($customer['user_name']); ?></td>
                        <td>RM <?php echo number_format($customer['investment_amount'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
