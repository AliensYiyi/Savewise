<?php
session_start();
include "conn.php";

$userId = intval($_GET['user_id']);

// Fetch chat messages for the selected user
$stmt = $conn->prepare("SELECT * FROM chat WHERE user_id = ? ORDER BY created_at ASC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}
$stmt->close();
$conn->close();

header('Content-Type: application/json');
echo json_encode($messages);
?>
