<?php
session_start();
include "conn.php";

// Ensure only admin can access this page
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch recent transactions with user details
$stmt = $conn->prepare("SELECT user.user_name, investmenthistory.amount, investmenthistory.type, investmenthistory.date 
                        FROM investmenthistory 
                        JOIN investments ON investmenthistory.investment_id = investments.investment_id 
                        JOIN total ON investments.total_id = total.total_id 
                        JOIN user ON total.user_id = user.user_id 
                        ORDER BY investmenthistory.date DESC LIMIT 5");
$stmt->execute();
$result = $stmt->get_result();
$recentTransactions = [];
while ($row = $result->fetch_assoc()) {
    $recentTransactions[] = $row;
}
$stmt->close();

// Fetch recent customer queries (only user messages)
$stmt = $conn->prepare("SELECT user.user_name, chat.message, chat.created_at 
                        FROM chat 
                        JOIN user ON chat.user_id = user.user_id 
                        WHERE chat.sender_role = 'User'
                        ORDER BY chat.created_at DESC LIMIT 5");
$stmt->execute();
$result = $stmt->get_result();
$recentQueries = [];
while ($row = $result->fetch_assoc()) {
    $recentQueries[] = $row;
}
$stmt->close();

// Fetch investment overview
$stmt = $conn->prepare("SELECT COUNT(*) as total_customers, SUM(investment_amount) as total_investment FROM investments");
$stmt->execute();
$stmt->bind_result($totalCustomers, $totalInvestment);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Main Page</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #F8F9FA; /* Light Gray */
        }

        .site-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 2cm;
            background-color: #007BFF; /* Primary Blue */
            border-bottom: 1px solid #ccc;
            padding: 0 1em;
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            height: 24px;
            margin-right: 8px;
        }

        .site-nav {
            display: flex;
            align-items: center;
        }

        .site-nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #FFF; /* White */
            margin-right: 50px;
        }

        .site-nav a:hover {
            color: #FF6F61; /* Soft Orange */
            background-color: #5BC0EB; /* Light Blue */
        }

        .user-info {
            margin-left: auto;
            padding: 0 1em;
        }

        .container {
            padding: 20px;
            margin-top: 50px;
        }

        .card-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
        }

        .card {
            background-color: #fff;
            width: 300px;
            margin: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            text-align: center;
            padding: 20px;
            text-decoration: none;
            color: #000;
            transition: transform 0.2s;
        }

        .card:hover {
            transform: scale(1.05);
            background-color: #5BC0EB; /* Light Blue */
            color: #FFF; /* White */
        }

        .card img {
            width: 100px;
            height: 100px;
        }

        .card h3 {
            margin: 10px 0;
            font-size: 20px;
        }

        .card p {
            margin: 10px 0;
            color: #666;
        }

        .preview {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            margin: 20px;
        }

        .preview h3 {
            margin-top: 0;
            font-size: 18px;
        }

        .preview table {
            width: 100%;
            border-collapse: collapse;
        }

        .preview table, .preview th, .preview td {
            border: 1px solid #ddd;
        }

        .preview th, .preview td {
            padding: 10px;
            text-align: left;
        }

        .preview th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <?php include('admin_navigation.php'); ?>

    <div class="preview">
        <div class="container">
            <div class="card-container">
                <a href="admin_view_user_information.php" class="card">
                    <h3>Customer Information</h3>
                    <p>View all customer data</p>
                </a>
                <a href="admin_analysis.php" class="card">
                    <h3>Customer Analysis</h3>
                    <p>Analyze customer data</p>
                </a>
                <a href="admin.php" class="card">
                    <h3>Customer Service</h3>
                    <p>Manage customer queries</p>
                </a>
                <a href="admin_update_roi.php" class="card">
                    <h3>Update ROI</h3>
                    <p>Update ROI for investments</p>
                </a>
            </div>
        </div>

        <div class="preview">
            <h3>Recent Transactions</h3>
            <table>
                <thead>
                    <tr>
                        <th>User Name</th>
                        <th>Amount</th>
                        <th>Type</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentTransactions as $transaction): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($transaction['user_name']); ?></td>
                            <td>RM <?php echo number_format($transaction['amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($transaction['type']); ?></td>
                            <td><?php echo htmlspecialchars($transaction['date']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="preview">
            <h3>Recent Customer Queries</h3>
            <table>
                <thead>
                    <tr>
                        <th>User Name</th>
                        <th>Message</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentQueries as $query): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($query['user_name']); ?></td>
                            <td><?php echo htmlspecialchars($query['message']); ?></td>
                            <td><?php echo htmlspecialchars($query['created_at']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="preview">
            <h3>Investment Overview</h3>
            <table>
                <thead>
                    <tr>
                        <th>Total Customers</th>
                        <th>Total Investment</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo $totalCustomers; ?></td>
                        <td>RM <?php echo number_format($totalInvestment, 2); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>