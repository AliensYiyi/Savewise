<?php if (session_status() == PHP_SESSION_NONE) {
    session_start();
} ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Header</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .site-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 2cm; /* Height of the header */
            background-color: #007bff; /* Change the background color */
            border-bottom: 1px solid #ccc;
            padding: 0 1em;
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            height: 60px; /* Adjust the height of the logo as needed */
            margin-right: 16px; /* Increase the margin for better spacing */
        }

        .site-nav {
            display: flex;
            align-items: center;
            margin-right: 10px;
            flex: 1;
            justify-content: center; /* Center the navigation items */
        }

        .site-nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #fff; /* Change the text color to white */
            padding: 10px 20px; /* Add padding for a better clickable area */
            border-radius: 5px; /* Add border radius for rounded corners */
            transition: background-color 0.3s; /* Smooth transition for hover effect */
        }

        .site-nav a:hover {
            color: #4CAF50;
            background-color: #fff; /* Change background color on hover */
        }

        .user-info {
            margin-left: auto;
            padding: 0 1em;
            color: #fff; /* Change the text color to white */
        }

        .logout {
            color: #fff; /* Change the text color to white */
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .logout:hover {
            background-color: #fff;
            color: #4CAF50; /* Change the text color to green on hover */
        }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="logo">
            <a href="admin_signup.php">
                <img src="logo.png" alt="Logo">
            </a>
        </div>
        <nav class="site-nav">
            <a href="admin_main.php">Admin Main Menu</a>
            <a href="admin_view_user_information.php">Customer Information</a>
            <a href="admin_analysis.php">Customer Analysis</a>
            <a href="admin.php">Customer Service</a>
            <a href="admin_update_roi.php">Update ROI</a>
        </nav>
        <?php if (isset($_SESSION['admin_id'])): ?>
            <div class="user-info">
                Admin ID: <?php echo $_SESSION['admin_id']; ?>
            </div>
        <?php endif; ?>
        <a href="index.html" class="logout">Log Out</a>
    </header>
</body>
</html>
