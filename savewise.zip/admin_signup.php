<?php
session_start();
include "conn.php"; // Include your database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $adminName = trim($_POST["admin_name"]);
    $adminPassword = trim($_POST["admin_password"]);

    // Check if the admin name already exists
    $stmt = $conn->prepare("SELECT admin_name FROM admin WHERE admin_name = ?");
    $stmt->bind_param("s", $adminName);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "<script>alert('Admin name already exists. Please choose a different name.'); window.location.href='admin_signup.php';</script>";
    } else {
        // Insert new admin into the database
        $stmt = $conn->prepare("INSERT INTO admin (admin_name, admin_password) VALUES (?, ?)");
        $stmt->bind_param("ss", $adminName, $adminPassword);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "<script>alert('New admin account created.'); window.location.href='admin_main.php';</script>";
            exit();
        } else {
            echo "Failed to register admin.";
        }
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Signup</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            height: 100vh;
            justify-content: center;
            align-items: center;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            text-align: center;
            margin-top: 40px;
            margin-left: 500px;
        }

        h2 {
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            text-align: left;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input[type="text"], 
        input[type="password"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            padding: 10px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<?php include('admin_navigation.php'); ?>
    <div class="container">
        <h2>Admin Signup</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="admin_name">Admin Name:</label>
            <input type="text" id="admin_name" name="admin_name" required>

            <label for="admin_password">Admin Password:</label>
            <input type="text" id="admin_password" name="admin_password" autocomplete="off" required>

            <button type="submit">New Admin</button>
        </form>
    </div>
</body>
</html>
