<?php
session_start();
include "conn.php";

// Ensure only admin can access this page
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Fetch investments for the admin to update
$stmt = $conn->prepare("
    SELECT investments.investment_id, investments.total_id, investments.investment_amount, investments.total_investment, investments.roi_percentage, investments.dividen, user.user_name
    FROM investments
    JOIN total ON investments.total_id = total.total_id
    JOIN user ON total.user_id = user.user_id
");
$stmt->execute();
$result = $stmt->get_result();
$investments = [];
while ($row = $result->fetch_assoc()) {
    $investments[] = $row;
}
$stmt->close();

// Handle ROI update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_roi'])) {
    $investmentId = intval($_POST['investment_id']);
    $roiPercentage = floatval($_POST['roi_percentage']);
    $dividendPercentage = floatval($_POST['dividen']);

    // Update ROI and dividend in the Investments table
    $stmt = $conn->prepare("UPDATE investments SET roi_percentage = ?, dividen = ? WHERE investment_id = ?");
    $stmt->bind_param("ddi", $roiPercentage, $dividendPercentage, $investmentId);
    $stmt->execute();

    // Recalculate total investment
    $stmt = $conn->prepare("SELECT investment_amount FROM investments WHERE investment_id = ?");
    $stmt->bind_param("i", $investmentId);
    $stmt->execute();
    $stmt->bind_result($investmentAmount);
    $stmt->fetch();
    $stmt->close();

    $roiAmount = $investmentAmount * ($roiPercentage / 100);
    $dividendAmount = $investmentAmount * ($dividendPercentage / 100);
    $totalInvestment = $investmentAmount + $roiAmount + $dividendAmount;

    $stmt = $conn->prepare("UPDATE investments SET total_investment = ? WHERE investment_id = ?");
    $stmt->bind_param("di", $totalInvestment, $investmentId);
    $stmt->execute();
    $stmt->close();

    header("Location: admin_update_roi.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update ROI and Dividend</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 900px;
            margin: 40px auto;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        button:hover {
            background-color: #0056b3;
        }

        form {
            display: inline-block;
        }
        

        .form-group label {
            width: 150px; /* Adjust width as needed */
            margin-right: 10px;
            text-align: right;
        }

        .form-group input {
            flex: 1;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .form-group button {
            margin-top: 10px;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }

        form {
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
<?php include('admin_navigation.php'); ?>
    <div class="container">
        <h2>Update ROI and Dividend</h2>
        <table>
            <thead>
                <tr>
                    <th>Investment ID</th>
                    <th>User Name</th>
                    <th>Investment Amount</th>
                    <th>Total Investment</th>
                    <th>ROI </th>
                    <th>Dividend</th>
                    <th>Update</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($investments as $investment): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($investment['investment_id']); ?></td>
                        <td><?php echo htmlspecialchars($investment['user_name']); ?></td>
                        <td>RM <?php echo number_format($investment['investment_amount'], 2); ?></td>
                        <td>RM <?php echo number_format($investment['total_investment'], 2); ?></td>
                        <td><?php echo number_format($investment['roi_percentage'], 2); ?>%</td>
                        <td><?php echo number_format($investment['dividen'], 2); ?>%</td>
                        <td>
                        <form method="POST" action="admin_update_roi.php">
                            <div class="form-group">
                                <label for="roi_percentage">Roi Percentage</label>
                                <input type="hidden" name="investment_id" value="<?php echo htmlspecialchars($investment['investment_id']); ?>">
                                <input type="number" placeholder="roi percentage" name="roi_percentage" value="<?php echo htmlspecialchars($investment['roi_percentage']); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="dividen">Dividen</label>
                                <input type="number" placeholder="dividen" name="dividen" value="<?php echo htmlspecialchars($investment['dividen']); ?>" required>
                            </div>
                            <div class="form-group">
                                <button type="submit" name="update_roi">Update</button>
                            </div>
                        </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
