<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $budgetName = $_POST['budgetName'];
    $budgetSetAmount = floatval($_POST['budgetSetAmount']);
    $wallet = $_POST['wallet'];
    $period = $_POST['period'];

    // Include your database connection file
    include "conn.php";

    // Get user ID from session
    $userId = $_SESSION['user_id'];

    $stmt = $conn->prepare("SELECT total_id FROM total WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($totalId);
    $stmt->fetch();
    $stmt->close();

    if (!$totalId) {
        // If the user does not have a total_id, redirect to the income entry page or show a message
        echo "<script>alert('Please Enter Income First.'); window.location.href='budget.php';</script>";
        exit();
    }

    // Insert the budget into the Budget table
    $stmt = $conn->prepare("INSERT INTO budget (Total_id, Budget_name, Budget_set_amount, Budget_spend_amount, Budget_wallet, Budget_period, last_reset_date) VALUES (?, ?, ?, 0, ?, ?, CURDATE())");
    $stmt->bind_param("isdss", $userId, $budgetName, $budgetSetAmount, $wallet, $period);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<script>alert('Budget added successfully!');</script>";
    } else {
        echo "Failed to add budget.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Budget</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            height: 100vh;
            justify-content: center;
            align-items: center;
        }

        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .budget-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 500px;
            text-align: center;
            margin-top: 40px;
        }

        .budget-container h2 {
            margin-bottom: 20px;
        }

        .budget-container .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .budget-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .budget-container input[type="text"], 
        .budget-container input[type="number"],
        .budget-container select {
            width: calc(100% - 20px);
            padding: 8px 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .budget-container button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
        }

        .budget-container button:hover {
            background-color: #0056b3;
        }

        @media (min-width: 768px) {
            .budget-container {
                width: 500px;
            }
        }
    </style>
</head>
<body>
    <?php include('navigation.php'); ?>
    <div class="box">
        <div class="budget-container">
            <h2>Add Budget</h2>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="budgetName">Budget Name</label>
                    <input type="text" id="budgetName" name="budgetName" required>
                </div>
                <div class="form-group">
                    <label for="budgetSetAmount">Amount</label>
                    <input type="number" id="budgetSetAmount" name="budgetSetAmount" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label for="wallet">Wallet</label>
                    <input type="text" id="wallet" name="wallet" required>
                </div>
                <div class="form-group">
                    <label for="period">Period</label>
                    <select id="period" name="period" required>
                        <option value="Daily">Daily</option>
                        <option value="Weekly">Weekly</option>
                        <option value="Monthly">Monthly</option>
                        <option value="Yearly">Yearly</option>
                    </select>
                </div>
                <button type="submit">Add</button>
            </form>
        </div>
    </div>
</body>
</html>
