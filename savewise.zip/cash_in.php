<?php
session_start();
include "conn.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = floatval($_POST['amount']);
    $date = $_POST['date'];
    $userId = $_SESSION['user_id'];

    // Check if the user has a total_id
    $stmt = $conn->prepare("SELECT total_id FROM total WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($totalId);
    $stmt->fetch();
    $stmt->close();

    if (!$totalId) {
        // If the user does not have a total_id, redirect to the income entry page or show a message
        echo "<script>alert('Please Enter Income First.'); window.location.href='investment.php';</script>";
        exit();
        exit();
    }

    // Fetch or create investment entry for the user
    $stmt = $conn->prepare("SELECT investment_id FROM investments WHERE total_id = ?");
    $stmt->bind_param("i", $totalId);
    $stmt->execute();
    $stmt->bind_result($investmentId);
    $stmt->fetch();
    $stmt->close();

    if (!$investmentId) {
        // Create investment entry if it doesn't exist
        $stmt = $conn->prepare("INSERT INTO investments (total_id, investment_amount, total_investment, roi_percentage, dividen) VALUES (?, 0, 0, 0, 0)");
        $stmt->bind_param("i", $totalId);
        $stmt->execute();
        $investmentId = $stmt->insert_id;
        $stmt->close();
    }

    // Insert Cash In history
    $stmt = $conn->prepare("INSERT INTO investmenthistory (investment_id, amount, type, date) VALUES (?, ?, 'Cash In', ?)");
    $stmt->bind_param("ids", $investmentId, $amount, $date);
    $stmt->execute();
    $stmt->close();

    // Update investment amount and total investment
    $stmt = $conn->prepare("UPDATE investments SET investment_amount = investment_amount + ?, total_investment = total_investment + ? WHERE investment_id = ?");
    $stmt->bind_param("ddi", $amount, $amount, $investmentId);
    $stmt->execute();
    $stmt->close();

    header("Location: investment.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cash In</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
            margin-top: 40px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<?php include('navigation.php'); ?>
    <div class="box">
        <div class="container">
        <h2>Cash In</h2>
        <form method="POST" action="cash_in.php">
            <input type="number" step="0.01" name="amount" placeholder="Amount" min="0" required>
            <input type="date" name="date" required>
            <button type="submit">Submit</button>
        </form>
    </div>
    </div>
    
</body>
</html>
