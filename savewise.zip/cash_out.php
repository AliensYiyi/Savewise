<?php
session_start();
include "conn.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = floatval($_POST['amount']);
    $date = $_POST['date'];
    $userId = $_SESSION['user_id'];

    // Fetch investment_id for the user
    $stmt = $conn->prepare("SELECT investment_id FROM investments WHERE total_id = (SELECT total_id FROM total WHERE user_id = ?)");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($investmentId);
    $stmt->fetch();
    $stmt->close();

    if (!$investmentId) {
        echo "No investment found.";
        exit();
    }

    // Insert Cash Out history
    $stmt = $conn->prepare("INSERT INTO investmenthistory (investment_id, amount, type, date) VALUES (?, ?, 'Cash Out', ?)");
    $stmt->bind_param("ids", $investmentId, $amount, $date);
    $stmt->execute();
    $stmt->close();

    // Update investment amount and total investment
    $stmt = $conn->prepare("UPDATE investments SET investment_amount = investment_amount - ?, total_investment = total_investment - ? WHERE investment_id = ?");
    $stmt->bind_param("ddi", $amount, $amount, $investmentId);
    $stmt->execute();
    $stmt->close();

    header("Location: investment.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cash Out</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
            text-align: center;
            margin-top: 40px;
            margin-left: 600px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        input {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<?php include('navigation.php'); ?>
    <div class="container">
        <h2>Cash Out</h2>
        <form method="POST" action="cash_out.php">
            <input type="number" step="0.01" name="amount" placeholder="Amount" min="0" required>
            <input type="date" name="date" required>
            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
