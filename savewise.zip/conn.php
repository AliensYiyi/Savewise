<?php
define("DB_USER", "id22361905_savewise");
define("DB_PASSWORD", "Savewise123@");
define("DB_HOST", "localhost");
define("DB_NAME", "id22361905_database");

$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the charset to UTF-8
if (!$conn->set_charset("utf8")) {
    printf("Error loading character set utf8: %s\n", $conn->error);
    exit();
}
?>
