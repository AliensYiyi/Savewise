<?php
session_start();
include "conn.php";

// Debugging: Check if user_id is set in the session
if (!isset($_SESSION['user_id'])) {
    die('User ID is not set in the session.');
}

$userId = $_SESSION['user_id'];

// Debugging: Check if user_id exists in the user table
$stmt = $conn->prepare("SELECT COUNT(*) FROM user WHERE User_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$stmt->bind_result($userExists);
$stmt->fetch();
$stmt->close();

if ($userExists == 0) {
    die('User ID does not exist in the user table.');
}

// Handle message sending
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $message = trim($_POST['message']);


    $stmt = $conn->prepare("INSERT INTO chat (user_id, message, sender_role) VALUES (?, ?, 'User')");
    $stmt->bind_param("is", $userId, $message);
    $stmt->execute();
    $stmt->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Chat</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            height: 100vh;
        }
        
        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .chat-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            width: 500px;
            max-width: 90%;
            display: flex;
            flex-direction: column;
            height: 80vh;
            margin-top: 20px;
        }

        .chat-header {
            margin-bottom: 20px;
            text-align: center;
        }

        .chat-box {
            border: 1px solid #ddd;
            border-radius: 10px;
            height: calc(100% - 100px); /* Fixed height for chat-box */
            overflow-y: auto;
            padding: 20px;
            background-color: #f9f9f9;
            flex: 1;
        }

        .message {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 10px;
            display: flex;
            flex-direction: column;
            max-width: 80%;
        }

        .message.user {
            background-color: #e0ffe0;
            align-self: flex-start;
            margin-left: 80px;
        }

        .message.admin {
            background-color: #e0e0ff;
            align-self: flex-end;
        }

        .message p {
            margin: 5px 0;
        }

        .message small {
            align-self: flex-end;
            color: #666;
        }

        .form-group {
            display: flex;
            margin-top: 20px;
        }

        .form-group input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px 0 0 5px;
            font-size: 16px;
        }

        .form-group button {
            padding: 10px 20px;
            border: none;
            border-radius: 0 5px 5px 0;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }
    </style>
    <script>
        function scrollToBottom() {
            var chatBox = document.querySelector('.chat-box');
            chatBox.scrollTop = chatBox.scrollHeight;
        }

        function fetchMessages() {
            fetch('fetch_messages.php')
                .then(response => response.json())
                .then(data => {
                    const chatBox = document.querySelector('.chat-box');
                    chatBox.innerHTML = '';
                    data.forEach(message => {
                        const messageDiv = document.createElement('div');
                        messageDiv.classList.add('message', message.sender_role.toLowerCase());
                        messageDiv.innerHTML = `<p><strong>${message.sender_role}:</strong></p>
                                                <p>${message.message}</p>
                                                <small>${message.created_at}</small>`;
                        chatBox.appendChild(messageDiv);
                    });
                    scrollToBottom();
                });
        }

        document.addEventListener('DOMContentLoaded', function () {
            scrollToBottom();
            fetchMessages();
            setInterval(fetchMessages, 5000); // Fetch messages every 5 seconds
        });
    </script>
</head>
<body>
    <?php include('navigation.php'); ?>
    <div class="box">
        <div class="chat-container">
        <h2 class="chat-header">Customer Service Chat</h2>
        <div class="chat-box"></div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <input type="text" name="message" placeholder="Type your message here..." required>
                <button type="submit">Send</button>
            </div>
        </form>
    </div>
    </div>
    
</body>
</html>
