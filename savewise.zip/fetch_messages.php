<?php
session_start();
include "conn.php";

$userId = $_SESSION['user_id'];

// Fetch chat messages
$stmt = $conn->prepare("SELECT * FROM chat WHERE user_id = ? ORDER BY created_at ASC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}
$stmt->close();
$conn->close();

echo json_encode($messages);
?>
