<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get user ID from session
    $userId = $_SESSION['user_id'];

    // Get income details from form
    $incomeName = trim($_POST["incomeName"]);
    $incomeType = trim($_POST["incomeType"]);
    $incomeAmount = floatval($_POST["incomeAmount"]);

    // Input validation
    if (!is_numeric($incomeAmount) || $incomeAmount <= 0) {
        echo "Please enter a valid positive number for the income amount.";
        exit();
    }

    include "conn.php"; // Include your database connection file

    // Check if there's already an entry for this user in the total table
    $stmt = $conn->prepare("SELECT total_income FROM total WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // User already has an entry, update the total_income
        $stmt->bind_result($currentIncome);
        $stmt->fetch();

        $newIncome = $currentIncome + $incomeAmount;

        // Update the total_income for the user
        $updateStmt = $conn->prepare("UPDATE total SET total_income = ? WHERE user_id = ?");
        $updateStmt->bind_param("di", $newIncome, $userId);
        $updateStmt->execute();


        $updateStmt->close();
    } else {
        // User doesn't have an entry yet, insert new record
        $insertStmt = $conn->prepare("INSERT INTO total (total_id, user_id, total_income) VALUES (?, ?, ?)");
        $insertStmt->bind_param("iid", $userId, $userId, $incomeAmount);
        $insertStmt->execute();


        $insertStmt->close();
    }

    $stmt->close();

    // Insert new income record into the income table
    $stmt = $conn->prepare("INSERT INTO income (user_id, income_name, income_type, income_amount) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("issd", $userId, $incomeName, $incomeType, $incomeAmount);
    $stmt->execute();

    $stmt->close();
    $conn->close();

    // Redirect the user to a confirmation page or the user dashboard
    header("Location: income.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Income Entry Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            height: 100vh;
            align-items: center;
            justify-content: center;
        }

        .box {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 500px;
            text-align: center;
            margin-top: 40px;
        }

        h2 {
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            text-align: left;
            margin-left: 10px;
        }

        input[type="text"], 
        input[type="number"], 
        select {
            width: calc(100% - 20px);
            padding: 8px 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="submit"] {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            margin-right: 10px;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <?php include('navigation.php'); ?>
    <div class="box">
        <div class="container">
            <h2>Enter Income</h2>
    
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <label for="incomeName">Income Name:</label>
                <input type="text" id="incomeName" name="incomeName" required>
    
                <label for="incomeType">Income Type:</label>
                <select id="incomeType" name="incomeType">
                    <option value="Salary">Salary</option>
                    <option value="Bonus">Bonus</option>
                    <option value="Other">Other</option>
                </select>
    
                <label for="incomeAmount">Income Amount:</label>
                <input type="number" id="incomeAmount" name="incomeAmount" step="0.01" min="0" required>
    
                <input type="submit" value="Enter Income">
            </form>
        </div>
    </div>
    
</body>
</html>
