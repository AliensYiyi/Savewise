<?php
session_start();
include "conn.php";

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$userId = $_SESSION['user_id'];

// Fetch investment details for the user
$stmt = $conn->prepare("SELECT investment_id, investment_amount, total_investment, roi_percentage, dividen FROM investments WHERE total_id = (SELECT total_id FROM total WHERE user_id = ?)");
$stmt->bind_param("i", $userId);
$stmt->execute();
$stmt->bind_result($investmentId, $investmentAmount, $totalInvestment, $roiPercentage, $dividendPercentage);
$stmt->fetch();
$stmt->close();

// Fetch investment history for the user
$investmentHistory = [];
if ($investmentId) {
    $stmt = $conn->prepare("SELECT amount, type, date FROM investmenthistory WHERE investment_id = ? ORDER BY date ASC");
    $stmt->bind_param("i", $investmentId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $investmentHistory[] = $row;
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Investment Overview</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 800px;
            margin: 40px auto;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        .button-group {
            margin-top: 20px;
        }

        .button-group a {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px;
            text-decoration: none;
            color: #fff;
            background-color: #007bff;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .button-group a:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            .container {
                width: 95%;
            }

            table, th, td {
                font-size: 14px;
            }

            .button-group a {
                padding: 8px 15px;
                font-size: 14px;
            }
        }

        @media (max-width: 480px) {
            table, th, td {
                font-size: 12px;
            }

            .button-group a {
                padding: 6px 10px;
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <?php include('navigation.php'); ?>

    <div class="container">
        <h2>Investment Overview</h2>

        <?php if ($investmentId): ?>
            <table>
                <thead>
                    <tr>
                        <th>Investment Amount</th>
                        <th>Total Investment</th>
                        <th>ROI (%)</th>
                        <th>Dividend (%)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>RM <?php echo number_format($investmentAmount, 2); ?></td>
                        <td>RM <?php echo number_format($totalInvestment, 2); ?></td>
                        <td><?php echo number_format($roiPercentage, 2); ?>%</td>
                        <td><?php echo number_format($dividendPercentage, 2); ?>%</td>
                    </tr>
                </tbody>
            </table>

            <h3>Investment History</h3>
            <table>
                <thead>
                    <tr>
                        <th>Amount</th>
                        <th>Type</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($investmentHistory as $history): ?>
                        <tr>
                            <td>RM <?php echo number_format($history['amount'], 2); ?></td>
                            <td><?php echo htmlspecialchars($history['type']); ?></td>
                            <td><?php echo htmlspecialchars($history['date']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <div class="button-group">
                <a href="cash_in.php">Cash In</a>
                <a href="cash_out.php">Cash Out</a>
            </div>
        <?php else: ?>
            <p>No investments found. Please add an investment.</p>
            <div class="button-group">
                <a href="cash_in.php">Cash In</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
