<?php
session_start();
include "conn.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loanAmount = floatval($_POST['loanAmount']);
    $loanTermYears = intval($_POST['loanTermYears']);
    $loanTermMonths = intval($_POST['loanTermMonths']);
    $interestRate = floatval($_POST['interestRate']);
    $compound = $_POST['compound'];
    $payBack = $_POST['payBack'];

    $totalMonths = ($loanTermYears * 12) + $loanTermMonths;
    $monthlyRate = ($interestRate / 100) / 12;

    if ($compound === 'monthly') {
        $n = 12;
    } elseif ($compound === 'weekly') {
        $n = 52;
    } else {
        $n = 365;
    }

    $totalPayments = $totalMonths;

    $numerator = $monthlyRate * pow(1 + $monthlyRate, $totalMonths);
    $denominator = pow(1 + $monthlyRate, $totalMonths) - 1;
    $monthlyPayment = $loanAmount * $numerator / $denominator;

    $totalPayment = $monthlyPayment * $totalPayments;
    $totalInterest = $totalPayment - $loanAmount;

    $queryString = http_build_query([
        'monthlyPayment' => number_format($monthlyPayment, 2),
        'totalPayments' => $totalPayments,
        'totalPayment' => number_format($totalPayment, 2),
        'totalInterest' => number_format($totalInterest, 2)
    ]);

    // Get the user ID from the session
    $userId = $_SESSION['user_id'];

    $stmt = $conn->prepare("SELECT total_id FROM total WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($totalId);
    $stmt->fetch();
    $stmt->close();

    if (!$totalId) {
        // If the user does not have a total_id, redirect to the income entry page or show a message
        echo "<script>alert('Please Enter Income First.'); window.location.href='loanCalculator.php';</script>";
        exit();
    }

    // Insert loan details into the Loan_calculator table
    $stmt = $conn->prepare("INSERT INTO loan_calculator (User_id, Loan_name, Loan_amount, Loan_duration, Loan_interest, Loan_monthly_due, Loan_total_pay) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $loanName = "Personal Loan"; // You can change this to a dynamic name if required
    $stmt->bind_param("isdiidd", $userId, $loanName, $loanAmount, $totalMonths, $interestRate, $monthlyPayment, $totalPayment);
    $stmt->execute();
    $stmt->close();

    // Redirect to the same page with query parameters
    header("Location: loanCalculator.php?$queryString");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loan Calculator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        
        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 600px;
            text-align: center;
            margin: 20px;
        }

        h1 {
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            text-align: left;
        }

        .form-inline {
            display: flex;
            flex-direction: column;
        }

        .form-inline input {
            width: 100%;
            margin-bottom: 15px;
        }

        input[type="text"], 
        input[type="number"], 
        select {
            width: 100%;
            padding: 8px 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            margin-right: 10px;
        }

        button:hover {
            background-color: #0056b3;
        }

        .result {
            margin-top: 20px;
        }

        @media (min-width: 600px) {
            .form-inline {
                flex-direction: row;
                justify-content: space-between;
                gap: 10px;
            }

            .form-inline input {
                width: calc(50% - 10px);
            }
        }
    </style>
</head>
<body>
    <?php include('navigation.php'); ?>
    
    <div class="box">
        <div class="container">
        <h1>Loan Calculator</h1>
        <form action="loanCalculator.php" method="post">
            <label for="loanAmount">Loan Amount</label>
            <input type="number" id="loanAmount" name="loanAmount" min="0" required>
            <div class="loan-term">
                <label>Loan Term</label>
                <div class="form-inline">
                    <input type="number" id="loanTermYears" name="loanTermYears" placeholder="Years" min="0">
                    <input type="number" id="loanTermMonths" name="loanTermMonths" placeholder="Months" min="0" required>
                </div>
            </div>

            <label for="interestRate">Interest Rate</label>
            <input type="number" id="interestRate" name="interestRate" step="any" min="0" required>

            <label for="compound">Compound</label>
            <select id="compound" name="compound">
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
            </select>

            <label for="payBack">Pay Back</label>
            <select id="payBack" name="payBack">
                <option value="daily">Daily</option>
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
            </select>

            <button type="submit">Calculate</button>
            <button type="reset">Clear</button>
        </form>

        <div class="result">
            <?php if (isset($_GET['monthlyPayment'])): ?>
                <p>Payment Every Month: RM<?php echo $_GET['monthlyPayment']; ?></p>
                <p>Total of <?php echo $_GET['totalPayments']; ?> Payments: RM<?php echo $_GET['totalPayment']; ?></p>
                <p>Total Interest: RM<?php echo $_GET['totalInterest']; ?></p>
            <?php endif; ?>
        </div>
    </div>
    </div>

    
</body>
</html>
