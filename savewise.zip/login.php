<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $userEmail = trim($_POST["email"]);
    $userPass = trim($_POST["password"]);

    include "conn.php";

    // Sanitize inputs
    $userEmail = htmlspecialchars($userEmail);

    // Check if the email exists in the users table
    $stmt = $conn->prepare("SELECT user_id, user_password FROM user WHERE user_email = ?");
    $stmt->bind_param("s", $userEmail);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // If the email exists in the users table, proceed with user login
        $stmt->bind_result($userId, $hashedPassword);
        $stmt->fetch();

        // Verify password
        if (password_verify($userPass, $hashedPassword)) {
            // Set session variables for user
            $_SESSION['user_id'] = $userId;
            $_SESSION['user_email'] = $userEmail;
            $stmt->close();
            $conn->close();
            header("Location: mainpage.php?userid=$userId");
            exit();
        } else {
            echo "<script>alert('Incorrect User Password'); window.location.href='index.html';</script>";
        }
    } else {
        // Check if the email exists in the admins table
        $stmt->close();
        $stmt = $conn->prepare("SELECT admin_id, admin_password FROM admin WHERE admin_name = ?");
        $stmt->bind_param("s", $userEmail);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // If the email exists in the admins table, proceed with admin login
            $stmt->bind_result($adminId, $adminPassword);
            $stmt->fetch();

            // Directly compare the plain text password
            if ($userPass === $adminPassword) {
                // Set session variables for admin
                $_SESSION['admin_id'] = $adminId;
                $_SESSION['admin_name'] = $userEmail;
                $stmt->close();
                $conn->close();
                header("Location: admin_main.php");
                exit();
            } else {
                echo "<script>alert('Incorrect Admin Password'); window.location.href='index.html';</script>";
            }
        } else {
            // Email does not exist in either table
            echo "<script>alert('No account found with that email'); window.location.href='index.html';</script>";
        }
    }

    $stmt->close();
    $conn->close();
}
?>
