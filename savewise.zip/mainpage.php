<?php
session_start();
include "conn.php";

// Set the timezone
date_default_timezone_set('Asia/Kuala_Lumpur');

// Get user ID from session
$userId = $_SESSION['user_id'];

function resetBudgetSpendAmount($conn, $userId) {
    // Fetch budgets that need to be reset
    $stmt = $conn->prepare("SELECT Budget_id, Budget_period, last_reset_date FROM budget WHERE Total_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $budgetId = $row['Budget_id'];
        $budgetPeriod = $row['Budget_period'];
        $lastResetDate = $row['last_reset_date'];

        $currentDate = new DateTime();
        $resetDate = new DateTime($lastResetDate);

        $interval = null;
        if ($budgetPeriod == 'Daily') {
            $interval = new DateInterval('P1D');
        } elseif ($budgetPeriod == 'Weekly') {
            $interval = new DateInterval('P1W');
        } elseif ($budgetPeriod == 'Monthly') {
            $interval = new DateInterval('P1M');
        } elseif ($budgetPeriod == 'Yearly') {
            $interval = new DateInterval('P1Y');
        }

        if ($interval) {
            $nextResetDate = clone $resetDate;
            $nextResetDate->add($interval);

            // Log date comparison
            error_log("Current Date: " . $currentDate->format('Y-m-d H:i:s'));
            error_log("Next Reset Date: " . $nextResetDate->format('Y-m-d H:i:s'));

            if ($nextResetDate <= $currentDate) {
                // Reset the Budget_spend_amount
                $updateStmt = $conn->prepare("UPDATE budget SET Budget_spend_amount = 0, last_reset_date = CURDATE() WHERE Budget_id = ?");
                $updateStmt->bind_param("i", $budgetId);
                $updateStmt->execute();
                $updateStmt->close();
            }
        }
    }

    $stmt->close();
}

// Call the reset function before fetching data
resetBudgetSpendAmount($conn, $userId);

// Function to reset saving progress based on period
function resetSavingProgress($conn, $userId) {
    // Fetch savings that need to be reset
    $stmt = $conn->prepare("SELECT Saving_id, last_update, Saving_current, saving_progress FROM saving WHERE Total_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $savingId = $row['Saving_id'];
        $lastResetDate = $row['last_update'];
        $savingCurrent = $row['Saving_current'];
        $savingProgress = $row['saving_progress'];

        $currentDate = new DateTime();
        $resetDate = new DateTime($lastResetDate);
        $resetDate->modify('first day of next month');

        // Log date comparison
        error_log("Current Date: " . $currentDate->format('Y-m-d H:i:s'));
        error_log("Reset Date: " . $resetDate->format('Y-m-d H:i:s'));

        if ($resetDate <= $currentDate) {
            // Update the saving_progress and reset Saving_current
            $newSavingProgress = $savingProgress;
            $updateStmt = $conn->prepare("UPDATE saving SET Saving_current = 0, saving_progress = ?, last_update = CURDATE() WHERE Saving_id = ?");
            $updateStmt->bind_param("di", $newSavingProgress, $savingId);
            $updateStmt->execute();
            $updateStmt->close();
        }
    }

    $stmt->close();
}

// Call the reset function before fetching data
resetSavingProgress($conn, $userId);

// Fetch total income
$stmt = $conn->prepare("SELECT total_income FROM total WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$stmt->bind_result($totalIncome);
$stmt->fetch();
$stmt->close();

// Fetch budget details
$stmt = $conn->prepare("SELECT Budget_name, Budget_set_amount, Budget_spend_amount FROM budget WHERE Total_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$budgets = [];
while ($row = $result->fetch_assoc()) {
    $budgets[] = $row;
}
$stmt->close();

// Fetch saving progress
$stmt = $conn->prepare("SELECT Saving_name, Saving_amount, Saving_current, saving_progress, saving_total FROM saving WHERE Total_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$savings = [];
while ($row = $result->fetch_assoc()) {
    $savings[] = $row;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main Page</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
        }

        /* New CSS for smaller screens */
        @media (max-width: 767px) {
            .container {
                background-color: #fff;
                padding: 20px;
                border-radius: 15px;
                box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
                margin: 50px auto;
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 20px;
                max-width: 1200px;
            }

            .box {
                background-color: #fafafa;
                border-radius: 15px;
                padding: 20px;
                box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
                text-align: center;
                width: 100%;
                max-width: 400px;
            }

            .box h2 {
                margin-bottom: 10px;
                font-size: 24px;
                color: #333;
            }

            .total-income {
                background: linear-gradient(135deg, #72EDF2 10%, #5151E5 100%);
                color: #fff;
            }

            .saving-monthly {
                background: #fff;
            }

            .saving-progress {
                background: #fff;
            }

            .budget {
                background: #fff;
            }

            .progress-bar {
                background-color: #e0e0e0;
                border-radius: 10px;
                padding: 5px;
                margin-top: 10px;
                position: relative;
                overflow: hidden;
            }

            .progress {
                height: 18px;
                border-radius: 10px;
                background-color: #76c7c0;
                width: 0;
                transition: width 0.5s ease-in-out;
            }

            .saving-monthly .progress {
                background-color: #6FBF73;
            }

            .saving-progress .progress {
                background-color: #6FBF73;
            }

            .budget .progress {
                background-color: #FF6F61;
            }

            .button-group {
                margin-top: 15px;
                display: flex;
                justify-content: center;
            }

            .button-group a {
                display: inline-block;
                padding: 10px 20px;
                margin: 5px;
                text-decoration: none;
                color: #fff;
                background-color: #007bff;
                border-radius: 5px;
                transition: background-color 0.3s;
            }

            .button-group a:hover {
                background-color: #0056b3;
            }
        }

        /* Old CSS for larger screens */
        @media (min-width: 768px) {
            .container {
                background-color: #fff;
                padding: 40px;
                border-radius: 15px;
                box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
                width: 80%;
                max-width: 1200px;
                margin: 50px auto;
                display: grid;
                grid-template-areas: 
                    "total-income total-income"
                    "saving-monthly budget"
                    "saving-progress saving-progress";
                gap: 30px;
            }

            .box {
                background-color: #fafafa;
                border-radius: 15px;
                padding: 30px;
                box-shadow: 0 0 15px rgba(0, 0, 0, 0.05);
                text-align: center;
            }

            .box h2 {
                margin-bottom: 20px;
                font-size: 24px;
                color: #333;
            }

            .total-income {
                grid-area: total-income;
                background: linear-gradient(135deg, #72EDF2 10%, #5151E5 100%);
                color: #fff;
            }

            .saving-monthly {
                grid-area: saving-monthly;
            }

            .saving-progress {
                grid-area: saving-progress;
            }

            .budget {
                grid-area: budget;
            }

            .progress-bar {
                background-color: #e0e0e0;
                border-radius: 10px;
                padding: 5px;
                margin-top: 15px;
                position: relative;
                overflow: hidden;
            }

            .progress {
                background-color: #76c7c0;
                height: 24px;
                border-radius: 10px;
                width: 0;
                transition: width 0.5s;
                max-width: 100%;
            }

            .saving-monthly .progress {
                background-color: #6FBF73;
            }

            .saving-progress .progress {
                background-color: #6FBF73;
            }

            .budget .progress {
                background-color: #FF6F61;
            }

            .button-group {
                margin-top: 20px;
            }

            .button-group a {
                display: inline-block;
                padding: 10px 20px;
                margin: 5px;
                text-decoration: none;
                color: #fff;
                background-color: #007bff;
                border-radius: 5px;
                transition: background-color 0.3s;
            }

            .button-group a:hover {
                background-color: #0056b3;
            }
        }
    </style>
</head>
<body>
    <?php include('navigation.php'); ?>

    <div class="container">
        <div class="box total-income">
            <h2>Total Income</h2>
            <p>RM <?php echo number_format($totalIncome, 2); ?></p>
            <div class="button-group">
                <a href="income.php">Add Income</a>
            </div>
        </div>

        <div class="box saving-monthly">
            <h2>Saving Monthly Progress</h2>
            <?php foreach ($savings as $saving): ?>
                <div>
                    <p><?php echo htmlspecialchars($saving['Saving_name']); ?>: RM <?php echo number_format($saving['Saving_current'], 2); ?> / RM <?php echo number_format($saving['Saving_amount'], 2); ?></p>
                    <div class="progress-bar">
                        <div class="progress" style="width: <?php echo ($saving['Saving_current'] / $saving['Saving_amount']) * 100; ?>%"></div>
                    </div>
                </div>
            <?php endforeach; ?>
            <div class="button-group">
                <a href="Saving/mainpage.php">Add Saving</a>
                <a href="update_saving.php">Update Saving</a>
            </div>
        </div>

        <div class="box budget">
            <h2>Budget</h2>
            <?php foreach ($budgets as $budget): ?>
                <div>
                    <p><?php echo htmlspecialchars($budget['Budget_name']); ?>: RM <?php echo number_format($budget['Budget_spend_amount'], 2); ?> / RM <?php echo number_format($budget['Budget_set_amount'], 2); ?></p>
                    <div class="progress-bar">
                        <div class="progress" style="width: <?php echo min(($budget['Budget_spend_amount'] / $budget['Budget_set_amount']) * 100, 100); ?>%"></div>
                    </div>
                </div>
            <?php endforeach; ?>
            <div class="button-group">
                <a href="budget.php">Add Budget</a>
                <a href="transaction.php">Update Budget</a>
            </div>
        </div>

        <div class="box saving-progress">
            <h2>Saving Progress</h2>
            <?php foreach ($savings as $saving): ?>
                <div>
                    <p><?php echo htmlspecialchars($saving['Saving_name']); ?>: RM <?php echo number_format($saving['saving_progress'], 2); ?> / RM <?php echo number_format($saving['saving_total'], 2); ?></p>
                    <div class="progress-bar">
                        <div class="progress" style="width: <?php echo ($saving['saving_progress'] / $saving['saving_total']) * 100; ?>%"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>

