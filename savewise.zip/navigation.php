

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Header</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        .site-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 2cm; /* Height of the header */
            background-color: #007bff; /* Change the background color */
            border-bottom: 1px solid #ccc;
            padding: 0 1em;
        }

        .logo {
            display: flex;
            align-items: center;
        }

        .logo img {
            height: 60px; /* Adjust the height of the logo as needed */
            margin-right: 16px; /* Increase the margin for better spacing */
        }

        .site-nav {
            display: flex;
            align-items: center;
            margin-right: 10px;
            flex: 1;
            justify-content: center; /* Center the navigation items */
        }

        .site-nav a {
            margin: 0 10px;
            text-decoration: none;
            color: #fff; /* Change the text color to white */
            padding: 10px 20px; /* Add padding for a better clickable area */
            border-radius: 5px; /* Add border radius for rounded corners */
            transition: background-color 0.3s; /* Smooth transition for hover effect */
        }

        .site-nav a:hover {
            color: #4CAF50;
            background-color: #fff; /* Change background color on hover */
        }

        .user-info, .logout {
            color: #fff; /* Change the text color to white */
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .user-info {
            margin-left: 20px; /* Space between user info and logout */
        }

        .logout {
            background-color: transparent; /* Make logout background transparent */
        }

        .logout:hover {
            background-color: #fff;
            color: #4CAF50; /* Change the text color to green on hover */
        }

        /* Media queries for smaller screens */
        @media (max-width: 768px) {
            .site-header {
                flex-direction: column;
                align-items: flex-start;
                height: auto;
            }

            .logo {
                width: 100%;
                justify-content: space-between;
            }

            .site-nav {
                display: none;
                flex-direction: column;
                width: 100%;
            }

            .site-nav.active {
                display: flex;
            }

            .site-nav a {
                margin: 0;
                width: 100%;
                text-align: center;
                padding: 15px;
                border-top: 1px solid #ccc;
            }

            .menu-toggle {
                display: block;
                background-color: #007bff;
                color: #fff;
                padding: 10px 20px;
                border: none;
                font-size: 16px;
                cursor: pointer;
                border-radius: 5px;
                transition: background-color 0.3s;
            }

            .menu-toggle:hover {
                background-color: #0056b3;
            }

            .user-info, .logout {
                width: 100%;
                text-align: center;
                padding: 10px 0;
            }

            .user-info {
                margin-left: 0;
            }
        }

        /* Hide menu-toggle button on larger screens */
        @media (min-width: 769px) {
            .menu-toggle {
                display: none;
            }
        }
    </style>
</head>
<body>
    <header class="site-header">
        <div class="logo">
            <img src="logo.png" alt="Logo">
            <button class="menu-toggle">Menu</button>
        </div>
        <nav class="site-nav">
            <a href="mainpage.php">Main Menu</a>
            <a href="income.php">Income</a>
            <a href="budget.php">Budget</a>
            <a href="transaction.php">Transaction</a>
            <a href="Saving/mainpage.php">Saving</a>
            <a href="investment.php">Investment</a>
            <a href="loanCalculator.php">Loan Calculator</a>
            <a href="customerService.php">Customer Service</a>
            <?php if (isset($_SESSION['user_id'])): ?>
        <?php endif; ?>
        <a href="index.html" class="logout">Log Out</a>
    </header>
        </nav>
        

    <script>
        document.querySelector('.menu-toggle').addEventListener('click', function() {
            document.querySelector('.site-nav').classList.toggle('active');
        });
    </script>
</body>
</html>
