<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car Deposit Result</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="result-container">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $price = $_POST['price'];
            $depositPercentage = $_POST['deposit'];
            $month = $_POST['buy_before_month'];
            $year = $_POST['buy_before_year'];

            $depositAmount = ($price * $depositPercentage) / 100;
            $currentMonth = date('n');
            $currentYear = date('Y');
            $monthsNeeded = (($year - $currentYear) * 12) + ($month - $currentMonth);
            $carDepositMonthly = $depositAmount / $monthsNeeded;
            $monthlyTarget = $carDepositMonthly;
        }
        ?>
        <p>To achieve your saving goal you need to save the related amount every month</p>
        <div class="result-box">
            <p>Monthly Target</p>
            <p class="amount">RM <?= number_format($monthlyTarget, 2) ?> / Month</p>
        </div>
        <div class="result-box">
            <img src="car_key_icon.png" alt="Car Key Icon">
            <p>Car Deposit</p>
            <p class="amount">RM <?= number_format($carDepositMonthly, 2) ?> / Month for <?= $monthsNeeded ?> month<?= $monthsNeeded > 1 ? 's' : '' ?></p>
        </div>
        <button onclick="window.location.href='index.php'">Create Goal</button>
    </div>
</body>
</html>
