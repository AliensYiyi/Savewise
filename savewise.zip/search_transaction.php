<?php
session_start();

include "conn.php";

$searchResult = null;
$error = null;
$success = null;
$allTransactions = null;

// Retrieve the success message from the session if it exists
if (isset($_SESSION['success'])) {
    $success = $_SESSION['success'];
    unset($_SESSION['success']);
}

// Get user ID from session
$userId = $_SESSION['user_id'];

// Initially fetch all transactions for the user
$stmt = $conn->prepare("SELECT * FROM transaction WHERE budget_id IN (SELECT Budget_id FROM budget WHERE Total_id = ?)");
$stmt->bind_param("i", $userId);
$stmt->execute();
$allTransactionsResult = $stmt->get_result();

if ($allTransactionsResult->num_rows > 0) {
    $allTransactions = $allTransactionsResult->fetch_all(MYSQLI_ASSOC);
}

$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['search'])) {
        $transactionName = trim($_POST['transactionName']);

        // Search for the transaction by name/title for the logged-in user
        $stmt = $conn->prepare("SELECT * FROM transaction WHERE transaction_name LIKE ? AND budget_id IN (SELECT Budget_id FROM budget WHERE Total_id = ?)");
        $searchTerm = "%{$transactionName}%";
        $stmt->bind_param("si", $searchTerm, $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $searchResult = $result->fetch_all(MYSQLI_ASSOC);
        } else {
            $error = "No transactions found with the name/title '{$transactionName}'.";
        }

        $stmt->close();
    } elseif (isset($_POST['edit'])) {
        // Handle edit transaction
        $transactionId = intval($_POST['transaction_id']);
        $newName = trim($_POST['new_name']);
        $newAmount = floatval($_POST['new_amount']);
        $newRemark = trim($_POST['new_remark']);
        $oldAmount = floatval($_POST['old_amount']);
        $budgetId = intval($_POST['budget_id']);

        // Calculate the difference in amount
        $amountDifference = $newAmount - $oldAmount;

        // Update the transaction
        $stmt = $conn->prepare("UPDATE transaction SET transaction_name = ?, transaction_amount = ?, transaction_remark = ? WHERE transaction_id = ?");
        $stmt->bind_param("sdsi", $newName, $newAmount, $newRemark, $transactionId);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Update the Budget_spend_amount in the Budget table
            $stmt = $conn->prepare("UPDATE budget SET Budget_spend_amount = Budget_spend_amount + ? WHERE Budget_id = ?");
            $stmt->bind_param("di", $amountDifference, $budgetId);
            $stmt->execute();
            $_SESSION['success'] = "Transaction updated successfully!";
            header("Location: search_transaction.php");
            exit();
        } else {
            $error = "Failed to update transaction.";
        }

        $stmt->close();
    } elseif (isset($_POST['delete'])) {
        // Handle delete transaction
        $transactionId = intval($_POST['transaction_id']);
        $amount = floatval($_POST['amount']);
        $budgetId = intval($_POST['budget_id']);

        // Delete the transaction
        $stmt = $conn->prepare("DELETE FROM transaction WHERE transaction_id = ?");
        $stmt->bind_param("i", $transactionId);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Update the Budget_spend_amount in the Budget table
            $stmt = $conn->prepare("UPDATE budget SET Budget_spend_amount = Budget_spend_amount - ? WHERE Budget_id = ?");
            $stmt->bind_param("di", $amount, $budgetId);
            $stmt->execute();
            $_SESSION['success'] = "Transaction deleted successfully!";
            header("Location: search_transaction.php");
            exit();
        } else {
            $error = "Failed to delete transaction.";
        }

        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Transaction</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            height: 100%;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .search-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 40px;
        }

        .search-container h2 {
            margin-bottom: 20px;
            text-align: center;
        }

        .search-container .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .search-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .search-container input[type="text"], 
        .search-container button {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        .search-container button {
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        .search-container button:hover {
            background-color: #0056b3;
        }

        .error, .success {
            margin-bottom: 15px;
            color: red;
            text-align: center;
        }

        .success {
            color: green;
        }

        .result-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .result-table th, .result-table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        .result-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }

        .edit-delete-container {
            padding: 10px;
            background-color: #f9f9f9;
            border-top: 1px solid #ddd;
            display: flex;
            justify-content: flex-start;
            align-items: center;
        }

        .edit-delete-buttons form {
            display: inline-block;
            margin-right: 10px;
        }

        .edit-delete-buttons form:last-child {
            margin-right: 0;
        }

        .form-group {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .form-group label {
            margin-right: 10px;
            white-space: nowrap;
        }

        .form-group input[type="text"],
        .form-group input[type="number"] {
            flex: 1;
            padding: 8px 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            margin-right: 10px;
        }

        .form-group input[type="text"]:last-child,
        .form-group input[type="number"]:last-child {
            margin-right: 0;
        }

        .form-group button {
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
            .search-container {
                width: 100%;
                padding: 10px;
            }

            .search-container .form-group {
                display: block;
            }

            .search-container button {
                width: 100%;
            }

            .edit-delete-container {
                flex-direction: column;
                align-items: flex-start;
            }

            .edit-delete-buttons form {
                width: 100%;
                margin-bottom: 10px;
            }

            .edit-delete-buttons form button {
                width: 100%;
            }

            .form-group {
                flex-direction: column;
                align-items: flex-start;
            }

            .form-group label {
                margin-bottom: 5px;
            }

            .form-group input[type="text"],
            .form-group input[type="number"] {
                width: 100%;
                margin-bottom: 10px;
                margin-right: 0;
            }
        }
    </style>
</head>
<body>
    <?php include('navigation.php'); ?>
    <div class="container">
        <div class="search-container">
            <h2>Search Transaction</h2>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="transactionName">Transaction Name/Title</label>
                    <input type="text" id="transactionName" name="transactionName" required>
                </div>
                <button type="submit" name="search">Search</button>
            </form>

            <?php if (!empty($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php elseif (!empty($success)): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if ($searchResult): ?>
                <table class="result-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Amount</th>
                            <th>Category</th>
                            <th>Date</th>
                            <th>Remark</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($searchResult as $transaction): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($transaction['transaction_name']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['transaction_amount']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['transaction_category']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['transaction_date']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['transaction_remark']); ?></td>
                            </tr>
                            <tr>
                                <td colspan="6">
                                    <div class="edit-delete-container">
                                        <!-- Edit form -->
                                        <div class="edit-delete-buttons">
                                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                                <input type="hidden" name="transaction_id" value="<?php echo htmlspecialchars($transaction['transaction_id']); ?>">
                                                <input type="hidden" name="budget_id" value="<?php echo htmlspecialchars($transaction['budget_id']); ?>">
                                                <input type="hidden" name="old_amount" value="<?php echo htmlspecialchars($transaction['transaction_amount']); ?>">
                                                
                                                <div class="form-group">
                                                    <label for="new_name_<?php echo $transaction['transaction_id']; ?>">New Name:</label>
                                                    <input type="text" id="new_name_<?php echo $transaction['transaction_id']; ?>" name="new_name" value="<?php echo htmlspecialchars($transaction['transaction_name']); ?>" required>
                                                </div>

                                                <div class="form-group">
                                                    <label for="new_amount_<?php echo $transaction['transaction_id']; ?>">New Amount:</label>
                                                    <input type="number" id="new_amount_<?php echo $transaction['transaction_id']; ?>" name="new_amount" step="0.01" value="<?php echo htmlspecialchars($transaction['transaction_amount']); ?>" required>
                                                </div>

                                                <div class="form-group">
                                                    <label for="new_remark_<?php echo $transaction['transaction_id']; ?>">New Remark:</label>
                                                    <input type="text" id="new_remark_<?php echo $transaction['transaction_id']; ?>" name="new_remark" value="<?php echo htmlspecialchars($transaction['transaction_remark']); ?>" required>
                                                </div>

                                                <button type="submit" name="edit">Edit</button>
                                            </form>

                                            <!-- Delete form -->
                                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                                <input type="hidden" name="transaction_id" value="<?php echo htmlspecialchars($transaction['transaction_id']); ?>">
                                                <input type="hidden" name="amount" value="<?php echo htmlspecialchars($transaction['transaction_amount']); ?>">
                                                <input type="hidden" name="budget_id" value="<?php echo htmlspecialchars($transaction['budget_id']); ?>">

                                                <button type="submit" name="delete">Delete</button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php elseif ($allTransactions): ?>
                <table class="result-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Amount</th>
                            <th>Category</th>
                            <th>Date</th>
                            <th>Remark</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($allTransactions as $transaction): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($transaction['transaction_name']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['transaction_amount']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['transaction_category']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['transaction_date']); ?></td>
                                <td><?php echo htmlspecialchars($transaction['transaction_remark']); ?></td>
                            </tr>
                            
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
