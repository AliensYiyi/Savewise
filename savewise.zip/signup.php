<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["Name"]);
    $userEmail = trim($_POST["email"]);
    $userPass = trim($_POST["password"]);
    $userDob = trim($_POST["dob"]);
    $userOccupation = trim($_POST["Occupation"]);

    include "conn.php";

    // Sanitize inputs
    $username = htmlspecialchars($username);
    $userEmail = htmlspecialchars($userEmail);
    $userDob = htmlspecialchars($userDob);
    $userOccupation = htmlspecialchars($userOccupation);

    // Check if email already exists
    $check_query = $conn->prepare("SELECT * FROM user WHERE user_email = ?");
    $check_query->bind_param("s", $userEmail);
    $check_query->execute();
    $result = $check_query->get_result();
    if ($result->num_rows > 0) {
        echo "<script>alert('The email is already used. Please choose a different email.');</script>";
        $check_query->close();
        $conn->close();
        echo '<meta http-equiv="refresh" content="0;url=signup.html">';
        return; // Exit function if email already exists    
    }

    // Hash the password
    $hashedPassword = password_hash($userPass, PASSWORD_BCRYPT);

    // Insert new user into the database
    $stmt = $conn->prepare("INSERT INTO user(user_email, user_name, user_password, user_dob, user_occupation) 
                            VALUES(?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $userEmail, $username, $hashedPassword, $userDob, $userOccupation);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<script>alert('Registered Successfully');</script>";
        echo '<meta http-equiv="refresh" content="0;url=index.html">';
    } else {
        echo "<script>alert('Registration failed. Please try again.');</script>";
        echo '<meta http-equiv="refresh" content="0;url=signup.html">';
    }

    $stmt->close();
    $conn->close();
}
?>
