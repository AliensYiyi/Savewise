<?php
session_start();

include "conn.php";

// Get the budget categories and their details from the Budget table
$stmt = $conn->prepare("SELECT Budget_id, Budget_name, Budget_set_amount, Budget_spend_amount, Budget_period, last_reset_date FROM budget WHERE Total_id = ?");
$userId = $_SESSION['user_id'];
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$categories = [];
while ($row = $result->fetch_assoc()) {
    $categories[] = $row;
}
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = floatval($_POST['amount']);
    $name = $_POST['Title'];
    $category = $_POST['category'];
    $date = $_POST['date'];
    $repeat = $_POST['repeat'];
    $remark = $_POST['remark'];

    // Find the selected category details in the array
    $selectedCategory = null;
    foreach ($categories as $cat) {
        if ($cat['Budget_name'] == $category) {
            $selectedCategory = $cat;
            break;
        }
    }

    if ($selectedCategory) {
        $budgetId = $selectedCategory['Budget_id'];
        $setAmount = $selectedCategory['Budget_set_amount'];
        $spendAmount = $selectedCategory['Budget_spend_amount'];
        $budgetPeriod = $selectedCategory['Budget_period'];
        $lastResetDate = $selectedCategory['last_reset_date'];

        // Check if the budget period has elapsed and reset the Budget_spend_amount if necessary
        $currentDate = new DateTime();
        $resetDate = new DateTime($lastResetDate);

        $interval = null;
        if ($budgetPeriod == 'Daily') {
            $interval = new DateInterval('P1D');
        } elseif ($budgetPeriod == 'Weekly') {
            $interval = new DateInterval('P1W');
        } elseif ($budgetPeriod == 'Monthly') {
            $interval = new DateInterval('P1M');
        } elseif ($budgetPeriod == 'Yearly') {
            $interval = new DateInterval('P1Y');
        }

        if ($interval && $resetDate->add($interval) <= $currentDate) {
            // Reset the Budget_spend_amount
            $stmt = $conn->prepare("UPDATE budget SET Budget_spend_amount = 0, last_reset_date = CURDATE() WHERE Budget_id = ?");
            $stmt->bind_param("i", $budgetId);
            $stmt->execute();
            $stmt->close();

            // Update the local spendAmount variable to reflect the reset
            $spendAmount = 0;
        }

        // Check if the new spend amount exceeds the set amount
        if ($spendAmount + $amount > $setAmount) {
            $error = "The spend amount exceeds the set amount for this category.";
        } else {
            // Update the Budget_spend_amount in the Budget table
            $stmt = $conn->prepare("UPDATE budget SET Budget_spend_amount = Budget_spend_amount + ? WHERE Budget_id = ?");
            $stmt->bind_param("di", $amount, $budgetId);
            $stmt->execute();
            
            if ($stmt->affected_rows > 0) {
                // Insert the new transaction into the Transaction table
                $stmt = $conn->prepare("INSERT INTO transaction (transaction_name, transaction_amount, transaction_category, transaction_date, transaction_repeat, transaction_remark, budget_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sdsssii", $name, $amount, $category, $date, $repeat, $remark, $budgetId);
                $stmt->execute();

                if ($stmt->affected_rows > 0) {
                    $success = "Transaction updated successfully!";
                } else {
                    $error = "Failed to add transaction.";
                }
            } else {
                $error = "Failed to update budget.";
            }

            $stmt->close();
        }
    } else {
        $error = "Invalid category selected.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Transaction</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            height: 100vh;
            justify-content: center;
            align-items: center;
        }

        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .transaction-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 90%;
            max-width: 500px;
            text-align: center;
            margin-top:40px;
        }

        .transaction-container h2 {
            margin-bottom: 20px;
        }

        .transaction-container .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        .transaction-container label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        .transaction-container input[type="text"], 
        .transaction-container input[type="date"],
        .transaction-container input[type="number"],
        .transaction-container select {
            width: calc(100% - 20px);
            padding: 8px 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .transaction-container button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
        }

        .transaction-container button:hover {
            background-color: #0056b3;
        }

        .error {
            color: red;
            margin-bottom: 15px;
        }

        .success {
            color: green;
            margin-bottom: 15px;
        }

        .search-btn {
            display: inline-block;
            margin-bottom: 20px;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #28a745;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            margin-top: 10px;
            width: 92%;
        }

        .search-btn:hover {
            background-color: #218838;
        }

        @media (min-width: 768px) {
            .transaction-container {
                width: 500px;
            }
        }
    </style>
</head>
<body>
    <?php include('navigation.php'); ?>
    <div class="box">
        <div class="transaction-container">
            <h2>Update Transaction</h2>
            
            <?php if (!empty($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php elseif (!empty($success)): ?>
                <div class="success"><?php echo $success; ?></div>
            <?php endif; ?>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="Title">Title</label>
                    <input type="text" id="Title" name="Title" required>
                </div>
                <div class="form-group">
                    <label for="amount">Amount</label>
                    <input type="number" id="amount" name="amount" step="0.01" required>
                </div>
                <div class="form-group">
                    <label for="category">Category</label>
                    <select id="category" name="category" required>
                        <?php if (count($categories) > 0): ?>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?php echo $category['Budget_name']; ?>"><?php echo $category['Budget_name']; ?></option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="" disabled>Please create a budget first</option>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="date">Date</label>
                    <input type="date" id="date" name="date" required>
                </div>
                <div class="form-group">
                    <label for="repeat">Repeat</label>
                    <select id="repeat" name="repeat" required>
                        <option value="None">None</option>
                        <option value="Weekly">Weekly</option>
                        <option value="Monthly">Monthly</option>
                        <option value="Yearly">Yearly</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="remark">Remark</label>
                    <input type="text" id="remark" name="remark">
                </div>
                <button type="submit" style="width:100%;" <?php echo (count($categories) == 0) ? 'disabled' : ''; ?>>Save</button>
                <a href="search_transaction.php" class="search-btn">Search Transaction</a>
            </form>
        </div>
    </div>
</body>
</html>
