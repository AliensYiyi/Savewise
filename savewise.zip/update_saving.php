<?php
session_start();
include "conn.php";

// Get user ID from session
$userId = $_SESSION['user_id'];

// Fetch savings details
$stmt = $conn->prepare("SELECT Saving_id, Saving_name, Saving_amount, Saving_current, last_update FROM saving WHERE Total_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$savings = [];
while ($row = $result->fetch_assoc()) {
    $savings[] = $row;
}
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $savingId = intval($_POST['saving_id']);
    $additionalAmount = floatval($_POST['new_current_amount']);
    
    // Fetch current saving details
    $stmt = $conn->prepare("SELECT Saving_current, last_update,saving_progress FROM saving WHERE Saving_id = ?");
    $stmt->bind_param("i", $savingId);
    $stmt->execute();
    $stmt->bind_result($currentSaving, $lastUpdate,$savingProgress);
    $stmt->fetch();
    $stmt->close();
    
    $currentDate = new DateTime();
    $lastUpdateDate = new DateTime($lastUpdate);
    $isSameMonth = $currentDate->format('Y-m') == $lastUpdateDate->format('Y-m');
    
    if (!$isSameMonth) {
        // Reset the current saving if last update was not in the current month
        $currentSaving = 0;
    }
    
    $newCurrentAmount = $currentSaving + $additionalAmount;
    $newProgress= $savingProgress + $additionalAmount;
    
    // Update the Saving_current, saving_progress, and last_update in the Saving table
    $stmt = $conn->prepare("UPDATE saving SET Saving_current = ?, saving_progress = ?, last_update = NOW() WHERE Saving_id = ?");
    $stmt->bind_param("ddi", $newCurrentAmount, $newProgress, $savingId);
    $stmt->execute();
    if ($stmt->affected_rows > 0) {
        $success = "Saving updated successfully!";
    } else {
        $error = "Failed to update saving.";
    }
    $stmt->close();
    header("Location: update_saving.php"); // Redirect to refresh the page and avoid resubmission
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Saving</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            height: 100vh;
        }
        
        .box {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }

        .container {
            background-color: #fff;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            width: 500px;
            max-width: 90%;
            margin: 50px auto;
        }

        h2 {
            margin-bottom: 20px;
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        select, input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background-color: #007bff;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #0056b3;
        }

        .message {
            text-align: center;
            margin-bottom: 20px;
        }

        .success {
            color: green;
        }

        .error {
            color: red;
        }
    </style>
</head>
<body>
    <?php include('navigation.php'); ?>
    <div class="box">
        <div class="container">
        <h2>Update Saving</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="saving_id">Select Saving</label>
                <select id="saving_id" name="saving_id" required>
                    <?php foreach ($savings as $saving): ?>
                        <option value="<?php echo $saving['Saving_id']; ?>"><?php echo htmlspecialchars($saving['Saving_name']); ?> (Current: RM <?php echo number_format($saving['Saving_current'], 2); ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="new_current_amount">New Current Amount</label>
                <input type="number" id="new_current_amount" name="new_current_amount" min="0" step="0.01" style="width: 96%;" required>
            </div>
            <button type="submit">Update Saving</button>
        </form>
    </div>
    </div>
    
</body>
</html>
